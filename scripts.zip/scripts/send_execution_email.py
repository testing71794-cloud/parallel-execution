#!/usr/bin/env python3
"""
Basic email sender script for Jenkins.

This is a template script that you can place inside:
scripts/send_execution_email.py

You can later customize SMTP details if needed.
"""

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
import sys


def main():
    # Placeholder configuration (update these)
    smtp_server = os.getenv("SMTP_SERVER", "smtp.example.com")
    smtp_port = int(os.getenv("SMTP_PORT", "587"))
    sender_email = os.getenv("SENDER_EMAIL", "sender@example.com")
    sender_password = os.getenv("SENDER_PASSWORD", "password")
    receiver_email = os.getenv("RECEIVER_EMAIL", "receiver@example.com")

    subject = "Jenkins Execution Report"
    body = "Execution completed. Please check generated reports."

    try:
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = receiver_email
        message["Subject"] = subject

        message.attach(MIMEText(body, "plain"))

        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, receiver_email, message.as_string())
        server.quit()

        print("Email sent successfully.")
        sys.exit(0)

    except Exception as e:
        print(f"Email sending failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
